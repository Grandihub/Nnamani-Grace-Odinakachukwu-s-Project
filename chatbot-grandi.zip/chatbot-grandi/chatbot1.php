<?php
require 'vendor/autoload.php'; // Ensure Guzzle is installed via Composer

use GuzzleHttp\Client;

header('Content-Type: application/json');

// Get user input
$input = json_decode(file_get_contents("php://input"), true);
$userMessage = trim($input['message']);

// Set up Cohere API request
$client = new Client([
    'base_uri' => 'https://api.cohere.ai/',
    'headers' => [
        'Authorization' => 'Bearer ffixNR6jqaor4PBGjPsKYIcLpx8Mjf10NwMKzoQE',
        'Content-Type' => 'application/json',
        'Cohere-Version' => '2022-12-06'
    ]
]);

$requestData = [
    'chat_history' => [],
    'message' => $userMessage,
    'model' => 'command-r-plus', // as of May 2025
    'temperature' => 0.7,
    'max_tokens' => 300,
];

try {
    $response = $client->post('v1/chat', ['json' => $requestData]);
    $data = json_decode($response->getBody(), true);
    $botMessage = $data['text'] ?? "Sorry, I couldn't generate a response.";
} catch (Exception $e) {
    $botMessage = "Error: " . $e->getMessage();
}

// Save to DB
try {
    $pdo = new PDO("mysql:host=localhost;dbname=blog_db", "root", "");
    $stmt = $pdo->prepare("INSERT INTO chatbot_messages (user_message, bot_response) VALUES (?, ?)");
    $stmt->execute([$userMessage, $botMessage]);
} catch (PDOException $e) {
    // Optionally log the DB error
}

echo json_encode(['response' => $botMessage]);
