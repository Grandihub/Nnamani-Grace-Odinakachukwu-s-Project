<?php
require 'vendor/autoload.php';
header('Content-Type: application/json');

// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=blog_db", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $pdo->prepare("SELECT * FROM chatbot_interactions WHERE id = ?");
$stmt->execute([$_GET['id']]);
$conversation = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($conversation);