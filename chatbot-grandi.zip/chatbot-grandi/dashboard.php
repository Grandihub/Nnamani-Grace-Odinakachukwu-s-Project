<?php
require 'vendor/autoload.php';
session_start();

// Authentication check
// if (!isset($_SESSION['loggedin'])) {
//     header('Location: login.php');
//     exit;
// }

// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=blog_db", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Get all conversations
$stmt = $pdo->query("SELECT * FROM chatbot_interactions ORDER BY created_at DESC");
$interactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get statistics
$stats = $pdo->query("SELECT 
    COUNT(*) as total_conversations,
    SUM(response_type = 'direct') as direct_answers,
    SUM(response_type = 'ai') as ai_answers
    FROM chatbot_interactions")->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHSPS Chatbot Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
    <style>
        .interaction-card {
            transition: all 0.3s;
            border-left: 4px solid #3498db;
        }
        .interaction-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .direct-answer { border-left-color: #2ecc71; }
        .ai-answer { border-left-color: #e74c3c; }
        .stat-card {
            border-radius: 8px;
            padding: 20px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block bg-dark sidebar">
                <div class="position-sticky pt-3">
                    <ul class="nav flex-column">
                        <li class="nav-item">
                            <a class="nav-link active text-white" href="#">
                                <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">
                                <i class="fas fa-comments me-2"></i> Conversations
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="#">
                                <i class="fas fa-cog me-2"></i> Settings
                            </a>
                        </li>
                    </ul>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">
                <h2 class="mb-4">Chatbot Analytics Dashboard</h2>
                
                <!-- Stats Cards -->
                <div class="row mb-4">
                    <div class="col-md-4">
                        <div class="stat-card bg-primary text-white">
                            <h5>Total Conversations</h5>
                            <h2><?= $stats['total_conversations'] ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card bg-success text-white">
                            <h5>Direct Answers</h5>
                            <h2><?= $stats['direct_answers'] ?></h2>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="stat-card bg-danger text-white">
                            <h5>AI Answers</h5>
                            <h2><?= $stats['ai_answers'] ?></h2>
                        </div>
                    </div>
                </div>

                <!-- Recent Conversations -->
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5>Recent Conversations</h5>
                        <div>
                            <button class="btn btn-sm btn-outline-primary">Export Data</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <table id="conversationsTable" class="table table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>User Message</th>
                                    <th>Bot Response</th>
                                    <th>Type</th>
                                    <th>Timestamp</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($interactions as $interaction): ?>
                                <tr>
                                    <td><?= $interaction['id'] ?></td>
                                    <td><?= htmlspecialchars(substr($interaction['user_message'], 0, 50)) ?>...</td>
                                    <td><?= htmlspecialchars(substr($interaction['bot_response'], 0, 50)) ?>...</td>
                                    <td>
                                        <span class="badge bg-<?= $interaction['response_type'] == 'direct' ? 'success' : 'danger' ?>">
                                            <?= strtoupper($interaction['response_type']) ?>
                                        </span>
                                    </td>
                                    <td><?= date('M j, Y g:i a', strtotime($interaction['created_at'])) ?></td>
                                    <td>
                                        <button class="btn btn-sm btn-outline-info view-details" 
                                                data-id="<?= $interaction['id'] ?>">Details</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Modal for Conversation Details -->
    <div class="modal fade" id="detailsModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Conversation Details</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <strong>User Message:</strong>
                        <p id="detail-user-message" class="mt-1 p-2 bg-light rounded"></p>
                    </div>
                    <div class="mb-3">
                        <strong>Bot Response:</strong>
                        <p id="detail-bot-response" class="mt-1 p-2 bg-light rounded"></p>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <strong>Response Type:</strong>
                            <p id="detail-response-type" class="mt-1"></p>
                        </div>
                        <div class="col-md-6">
                            <strong>Timestamp:</strong>
                            <p id="detail-timestamp" class="mt-1"></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.4/js/dataTables.bootstrap5.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <script>
        $(document).ready(function() {
            $('#conversationsTable').DataTable({
                order: [[4, 'desc']]
            });

            // Handle details button clicks
            $('.view-details').click(function() {
                const id = $(this).data('id');
                $.get('get_conversation.php?id=' + id, function(data) {
                    $('#detail-user-message').text(data.user_message);
                    $('#detail-bot-response').text(data.bot_response);
                    $('#detail-response-type').html(
                        `<span class="badge bg-${data.response_type == 'direct' ? 'success' : 'danger'}">` +
                        data.response_type.toUpperCase() + '</span>');
                    $('#detail-timestamp').text(new Date(data.created_at).toLocaleString());
                    $('#detailsModal').modal('show');
                });
            });
        });
    </script>
</body>
</html>