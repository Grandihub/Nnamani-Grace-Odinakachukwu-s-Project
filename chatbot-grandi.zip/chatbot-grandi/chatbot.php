<?php
require 'vendor/autoload.php';

use GuzzleHttp\Client;

header('Content-Type: application/json');

// Get user input
$input = json_decode(file_get_contents("php://input"), true);
$userMessage = trim(strtolower($input['message']));

// Database connection
$pdo = new PDO("mysql:host=localhost;dbname=blog_db", "root", "");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Proactive messages for user engagement
// These messages are sent if the user is inactive or if they mention specific keywords
// $proactiveMessages = [
//     'inactive' => [
//         "Still there? Let me know if you need help with our SME solutions!",
//         "Need help choosing the right business software? I can guide you!",
//         "Our team can create custom solutions for your business. Want to discuss?"
//     ],
//     'keywords' => [
//         'website' => "Need a business website? We offer packages starting at ₦150,000!",
//         'pos' => "Ask about our POS systems with inventory management!",
//         'accounting' => "Our accounting software automates tax calculations. Want details?"
//     ]
// ]; 


// PHSPS Apps Business Knowledge Base
$businessFacts = [
    "about" => "PHSPS Apps is a business solutions provider for SMEs, specializing in custom software, mobile apps, and digital transformation. We're located at 8 Elias Lane, Kemberi, Okokomaiko, Lagos.",
    "services" => "We offer: **1) Custom Business Software (₦500,000+) **2) Mobile Applications (₦1,500,000+) **3) Website Development (₦200,000+) **4) Digital Consulting (₦50,000/hr) **5) Networking and CBT Apps",
    "pricing" => "Our projects start from ₦200,000 for basic websites to ₦5,000,000+ for enterprise solutions. Contact us for a free quote based on your specific needs.",
    "contact" => "Reach us at: 📞 +234(0)808-400-8191 📧 info@phsps.com 🌍 8 Elias Lane, Kemberi, Okokomaiko, Lagos Also at F882 Alaba International Market, Ojo, Lagos",
    "contact2" => "All services are provided from our Lagos office. You can reach us via phone or email for any inquiries.",
    "hours" => "Our office hours are Monday-Friday 8:30am-5:30pm, Saturday 10am-3pm. Closed on Sundays and public holidays.",
    "team" => "Our team consists of 12 experienced professionals including software engineers, UI/UX designers, and business analysts.",
    "portfolio" => "We've served 50+ SMEs across Lagos including retail, healthcare, and logistics businesses. Ask about our case studies!",
    "process" => "Our workflow: 1) Consultation 2) Requirement Analysis 3) Proposal 4) Development 5) Testing 6) Deployment 7) Support"
];

// Common question patterns and their answers
$commonQuestions = [
    "what do you do" => "about",
    "services" => "services",
    "how much" => "pricing",
    "price" => "pricing",
    "cost" => "pricing",
    "contact" => "contact",
    "address" => "contact",
    "location" => "contact",
    "where are you" => "contact",
    "working hours" => "hours",
    "when are you open" => "hours",
    "team" => "team",
    "who are you" => "about",
    "portfolio" => "portfolio",
    "clients" => "portfolio",
    "examples" => "portfolio",
    "process" => "process",
    "how you work" => "process",
    "how do you work" => "process",
    "how does it work" => "process",
    "how can i contact you" => "contact",
    "how to reach you" => "contact",
    "i need a website" => "services",
    "i need a mobile app" => "services",
    "i need software" => "services",
    "i need a solution" => "services",
    "do you have a branch at <location>" => "contact2",
    "do you have a branch in <location>" => "contact2",
];


// // Check for proactive triggers
// function checkProactiveTriggers($userMessage, $chatHistory, $pdo) {
//     global $proactiveMessages;
    
//     // 1. Check for inactivity (simplified - in real app track time between messages)
//     if (count($chatHistory) > 2 && rand(0, 100) > 70) { // 30% chance after 3 messages
//         return $proactiveMessages['inactive'][array_rand($proactiveMessages['inactive'])];
//     }
    
//     // 2. Check for keywords
//     foreach ($proactiveMessages['keywords'] as $keyword => $message) {
//         if (stripos($userMessage, $keyword) !== false) {
//             // Don't repeat the same suggestion
//             $stmt = $pdo->prepare("SELECT COUNT(*) FROM chatbot_interactions 
//                                   WHERE bot_response LIKE ? AND created_at > NOW() - INTERVAL 5 MINUTE");
//             $stmt->execute(["%$message%"]);
//             if ($stmt->fetchColumn() == 0) {
//                 return $message;
//             }
//         }
//     }
    
//     return null;
// }

// // Initialize chat history
// $chatHistory = [];
// // Load previous interactions from the database
// try {
//     $stmt = $pdo->query("SELECT user_message, bot_response FROM chatbot_interactions ORDER BY created_at DESC LIMIT 10");
//     while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
//         $chatHistory[] = ['user' => $row['user_message'], 'bot' => $row['bot_response']];
//     }
// } catch (PDOException $e) {
//     error_log("DB Error: " . $e->getMessage());
// }   
// // Check for proactive messages
// $proactiveMessage = checkProactiveTriggers($userMessage, $chatHistory, $pdo);
// if ($proactiveMessage) {
//     // Log proactive message interaction
//     try {
//         $fields = [
//             'user_message' => $userMessage,
//             'bot_response' => $proactiveMessage,
//             'response_type' => 'proactive'
//         ];
//         insertInteraction($fields);
//     } catch (PDOException $e) {
//         error_log("DB Error: " . $e->getMessage()); 
//     }
//     echo json_encode(['response' => $proactiveMessage]);
//     exit;
// }




// Check for direct matches first
$matched = false;
foreach ($commonQuestions as $pattern => $factKey) {
    if (strpos($userMessage, $pattern) !== false) {
        echo json_encode(['response' => $businessFacts[$factKey]]);
        $matched = true;
        break;
    }
}

if ($matched) {
    // Log this interaction
    try {
        $fields = [
            'user_message' => $userMessage,
            'bot_response' => $businessFacts[$factKey],
            'response_type' => 'direct'
        ];
        insertInteraction($fields);
        
    } catch (PDOException $e) {
        error_log("DB Error: " . $e->getMessage());
    }
    exit;
}

// Prepare Cohere API request with business context
$businessContext = "You are an AI assistant for PHSPS Apps, a business solutions provider for SMEs based in Lagos, Nigeria. 
Key information about PHSPS Apps:
- Location: 8 Elias Lane, Kemberi, Okokomaiko, Lagos
- Services: Custom software, mobile apps, websites, digital consulting
- Pricing: Projects start from ₦200,000
- Hours: Mon-Fri 8:30am-5:30pm, Sat 10am-3pm
- Contact: +234(0)808-400-8191 or info@phsps.com

Always respond in a professional but friendly tone suitable for Nigerian business clients. 
If asked for information not provided here, politely indicate you don't have that information and suggest contacting the company directly.";

$client = new Client([
    'base_uri' => 'https://api.cohere.ai/',
    'headers' => [
        'Authorization' => 'Bearer ktFiaORrdfzqRCmQhp3ZJXd4auMaf3rXgJkPP52y',
        'Content-Type' => 'application/json',
        'Cohere-Version' => '2022-12-06'
    ]
]);

$requestData = [
    'chat_history' => [],
    'message' => $userMessage,
    'model' => 'command-r-plus',
    'temperature' => 0.5,
    'max_tokens' => 300,
    'preamble' => $businessContext
];

try {
    $response = $client->post('v1/chat', ['json' => $requestData]);
    $data = json_decode($response->getBody(), true);
    $botMessage = $data['text'] ?? "Thank you for your inquiry. For more specific information, please contact us directly at +234(0)808-400-8191.";
} catch (Exception $e) {
    $botMessage = "We're experiencing technical difficulties. Please call us directly at +234(0)808-400-8191 or email info@phsps.com.";
}

// Save to DB
try {
    $fields = [
        'user_message' => $userMessage,
        'bot_response' => $botMessage,
        'response_type' => 'ai'
    ];
    insertInteraction($fields);
    // Log the interaction  

} catch (PDOException $e) {
    error_log("DB Error: " . $e->getMessage());
}

echo json_encode(['response' => $botMessage]);


 //Insert new bill created to the bills table
    function insertInteraction(array $fields):void
    {
        global $pdo;
        $implodeColumns = implode(',', array_keys($fields));
        $implodePlaceholders = implode(', :', array_keys($fields));

        $sql = "INSERT INTO chatbot_interactions ($implodeColumns) VALUES (:".$implodePlaceholders.')';
        $stmt = $pdo->prepare($sql);
        foreach ($fields as $key => $value) {
            $stmt->bindValue(':'.$key, $value);
        }
        $stmt->execute();
    }