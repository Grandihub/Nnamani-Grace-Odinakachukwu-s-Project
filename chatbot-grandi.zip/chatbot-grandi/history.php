<?php
// history.php
$pdo = new PDO("mysql:host=localhost;dbname=blog_db", "root", "");
$stmt = $pdo->query("SELECT * FROM chatbot_messages ORDER BY created_at DESC");
$messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Chat History</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 20px; }
        .chat-entry { border-bottom: 1px solid #ddd; margin-bottom: 10px; padding-bottom: 10px; }
        .user-msg { color: blue; }
        .bot-msg { color: green; }
        .timestamp { font-size: 0.85em; color: gray; }
    </style>
</head>
<body>
    <h2>Chat History</h2>

    <?php foreach ($messages as $msg): ?>
        <div class="chat-entry">
            <div class="timestamp"><?= htmlspecialchars($msg['created_at']) ?></div>
            <div class="user-msg"><strong>You:</strong> <?= nl2br(htmlspecialchars($msg['user_message'])) ?></div>
            <div class="bot-msg"><strong>Bot:</strong> <?= nl2br(htmlspecialchars($msg['bot_response'])) ?></div>
        </div>
    <?php endforeach; ?>

</body>
</html>
